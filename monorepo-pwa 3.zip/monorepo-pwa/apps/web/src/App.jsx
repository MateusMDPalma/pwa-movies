import { useState } from 'react';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';

function App() {
  const [search, setSearch] = useState('');
  const [movies, setMovies] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [selectedMovie, setSelectedMovie] = useState(null);
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!search.trim()) return;

    setLoading(true);
    setError('');
    setSelectedMovie(null);
    setHasSearched(true);

    try {
      const res = await fetch(`${API_URL}/api/movies?search=${encodeURIComponent(search)}`);
      const data = await res.json();
      if (!data.ok) {
        setError(data.error || 'Erro ao buscar filmes');
        setMovies([]);
      } else {
        setMovies(data.movies || []);
      }
    } catch (err) {
      console.error(err);
      setError('Erro de conexão com a API.');
      setMovies([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectMovie = async (id) => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`${API_URL}/api/movies/${id}`);
      const data = await res.json();
      if (!data.ok) {
        setError(data.error || 'Erro ao buscar detalhes do filme');
        setSelectedMovie(null);
      } else {
        setSelectedMovie(data.movie);
      }
    } catch (err) {
      console.error(err);
      setError('Erro de conexão com a API.');
      setSelectedMovie(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app">
      <header className="app-header">
        <div className="brand">
          <span className="logo">🎬</span>
          <div>
            <h1>CinePWA</h1>
            <p>Descubra filmes, veja detalhes e explore seu próximo favorito.</p>
          </div>
        </div>
      </header>

      <main className="app-main">
        {/* Bloco de busca */}
        <section className="search-section">
          <div className="card search-card">
            <h2>Buscar filme</h2>
            <p className="helper-text">
              Digite o nome de um filme e clique em <strong>Buscar</strong>. Depois, selecione um
              resultado para ver os detalhes.
            </p>
            <form onSubmit={handleSearch} className="search-form">
              <label className="field">
                <span>Título do filme</span>
                <input
                  type="text"
                  placeholder="Ex: Inception, Batman, Matrix..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </label>
              <button type="submit" disabled={loading}>
                {loading ? 'Buscando...' : 'Buscar'}
              </button>
            </form>
            {error && <p className="error">{error}</p>}
            {!hasSearched && (
              <p className="hint">Dica: comece buscando por um título que você gosta. 😉</p>
            )}
          </div>
        </section>

        {/* Resultados + detalhes */}
        <section className="results-section">
          <div className="results-layout">
            {/* Lista de filmes */}
            <div className="card movies-card">
              <div className="card-header">
                <h2>Resultados</h2>
                {hasSearched && !loading && movies.length === 0 && (
                  <span className="badge badge-empty">Nenhum filme encontrado</span>
                )}
                {movies.length > 0 && (
                  <span className="badge">{movies.length} filme(s) encontrado(s)</span>
                )}
              </div>

              {!hasSearched && (
                <div className="empty-state">
                  <p>
                    Aqui vão aparecer os filmes que combinam com a sua busca. Use o campo acima
                    para começar.
                  </p>
                </div>
              )}

              {hasSearched && movies.length === 0 && !loading && (
                <div className="empty-state">
                  <p>
                    Não encontramos nada com esse título. Tente variar a grafia ou buscar apenas
                    uma palavra-chave.
                  </p>
                </div>
              )}

              <ul className="movies-list">
                {movies.map((movie) => (
                  <li
                    key={movie.id}
                    className={`movie-card ${
                      selectedMovie && selectedMovie.id === movie.id ? 'movie-card--active' : ''
                    }`}
                    onClick={() => handleSelectMovie(movie.id)}
                    data-testid="movie-card"
                  >
                    <img
                      src={
                        movie.poster !== 'N/A'
                          ? movie.poster
                          : 'https://via.placeholder.com/120x180?text=Sem+poster'
                      }
                      alt={movie.title}
                    />
                    <div className="movie-info">
                      <h3>{movie.title}</h3>
                      <p className="movie-meta">
                        <span>{movie.year}</span>
                        <span className="movie-type">
                          {movie.type === 'movie' ? 'Filme' : movie.type}
                        </span>
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>

            {/* Detalhes do filme */}
            <div className="card details-card">
              <h2>Detalhes do filme</h2>

              {!selectedMovie && (
                <div className="empty-state">
                  <p>
                    Selecione um filme na lista ao lado para ver mais informações como sinopse,
                    elenco, diretor e nota no IMDb.
                  </p>
                </div>
              )}

              {selectedMovie && (
                <div className="details-content">
                  <div className="details-header">
                    <img
                      src={
                        selectedMovie.poster !== 'N/A'
                          ? selectedMovie.poster
                          : 'https://via.placeholder.com/200x300?text=Sem+poster'
                      }
                      alt={selectedMovie.title}
                      className="details-poster"
                    />
                    <div className="details-main">
                      <h3>{selectedMovie.title}</h3>
                      <p className="details-meta">
                        <span>{selectedMovie.year}</span>
                        {selectedMovie.genre && <span>{selectedMovie.genre}</span>}
                        {selectedMovie.runtime && <span>{selectedMovie.runtime}</span>}
                      </p>
                      {selectedMovie.rating && (
                        <p className="rating">
                          ⭐ <strong>{selectedMovie.rating}</strong> no IMDb
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="details-body">
                    {selectedMovie.director && (
                      <p>
                        <span className="label">Direção:</span> {selectedMovie.director}
                      </p>
                    )}
                    {selectedMovie.actors && (
                      <p>
                        <span className="label">Elenco:</span> {selectedMovie.actors}
                      </p>
                    )}
                    {selectedMovie.plot && (
                      <p className="plot">
                        <span className="label">Sinopse:</span> {selectedMovie.plot}
                      </p>
                    )}
                  </div>

                  {/* Marcador para o teste E2E */}
                  <div data-testid="api-ok" />
                </div>
              )}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;
