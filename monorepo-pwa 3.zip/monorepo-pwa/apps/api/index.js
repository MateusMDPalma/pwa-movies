require('dotenv').config();
const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');

const app = express();

const OMDB_API_KEY = process.env.OMDB_API_KEY;
const PORT = process.env.PORT || 3000;

if (!OMDB_API_KEY) {
  console.warn('⚠️ OMDB_API_KEY não definido no .env. A API de filmes não vai funcionar.');
}

app.use(cors());

// Health check
app.get('/api/health', (req, res) => {
  res.json({ ok: true, msg: 'API de filmes online' });
});

// Busca de filmes: /api/movies?search=batman&page=1
app.get('/api/movies', async (req, res) => {
  try {
    const search = req.query.search;
    const page = req.query.page || 1;

    if (!search) {
      return res.status(400).json({ ok: false, error: 'Parâmetro "search" é obrigatório.' });
    }

    const url = `https://www.omdbapi.com/?apikey=${OMDB_API_KEY}&s=${encodeURIComponent(
      search
    )}&type=movie&page=${page}`;

    const response = await fetch(url);
    const data = await response.json();

    if (data.Response === 'False') {
      return res.status(404).json({ ok: false, error: data.Error || 'Nenhum filme encontrado.' });
    }

    // Normaliza resposta
    const movies = (data.Search || []).map((m) => ({
      id: m.imdbID,
      title: m.Title,
      year: m.Year,
      poster: m.Poster,
      type: m.Type
    }));

    res.json({
      ok: true,
      totalResults: Number(data.totalResults || movies.length),
      movies
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false, error: 'Erro interno na API de filmes.' });
  }
});

// Detalhes de um filme: /api/movies/:id
app.get('/api/movies/:id', async (req, res) => {
  try {
    const id = req.params.id;

    const url = `https://www.omdbapi.com/?apikey=${OMDB_API_KEY}&i=${encodeURIComponent(
      id
    )}&plot=full`;

    const response = await fetch(url);
    const data = await response.json();

    if (data.Response === 'False') {
      return res.status(404).json({ ok: false, error: data.Error || 'Filme não encontrado.' });
    }

    const movie = {
      id: data.imdbID,
      title: data.Title,
      year: data.Year,
      poster: data.Poster,
      plot: data.Plot,
      genre: data.Genre,
      runtime: data.Runtime,
      director: data.Director,
      actors: data.Actors,
      rating: data.imdbRating
    };

    res.json({ ok: true, movie });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false, error: 'Erro interno ao buscar detalhes do filme.' });
  }
});

app.listen(PORT, () => {
  console.log(`🎬 Movies API rodando em http://localhost:${PORT}`);
});
